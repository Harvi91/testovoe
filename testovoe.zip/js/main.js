$(function () {
  let text = $(".header-contacts").html(
    '<div class="header-contacts"><span class="phone-code"> +375 <span class=prefix>(29)</span></span> 111-13-33 <br /><p>звоните с 10 до 21</p></div>'
  );
});
